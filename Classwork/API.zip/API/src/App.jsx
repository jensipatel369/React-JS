import React from 'react'
import Api from './components/Api'
import Home from './components/Home'

export default function App() {
  return (
    <div>
      {/* <Api/> */}
      <Home/>
    </div>
  )
}
